Ross Miglin (rdm2965), Godson Inikori (agi93) Maria Krychniak (mck959): README File

-Open the each different PDE file and hit "Play" 
 

-To INTERACT:
	-For BAR GRAPH
		-If mouse pressed then sub labels on graph appear

	-For RSS READER
		-Click on words to link
		-Next button
		-Radio button
