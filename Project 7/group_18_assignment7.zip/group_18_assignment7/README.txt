Ross Miglin (rdm2965), Godson Inikori (agi93) Maria Krychniak (mck959): README File

-Open the PDE file and hit "Play" 

-The card game will appear 

-To INTERACT:
	-Press the "S" button to start/OR shuffle
		-The timer will start 
		-If the timer reaches 60 and player doesn't finish, player loses
	-Press the "R" button if you wish to restart the game
	-Mouse-click around on the cards to try and find a match
		-If a match the cards will disappear 
		-If not a match keep clicking around to find the pair (but can only 			flip two at a time)
	-Press the SPACEBAR if you wish to pause the timer during the game
	-Final score goes down the more time you take to match the cards
