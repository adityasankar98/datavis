Ross Miglin (rdm2965), Godson Inikori (agi93) Maria Krychniak (mck959): README File

-Open the PDE file and hit "Play" 

-Watch the animation ensue 

-To INTERACT: Click the mouse to simulate:
	-Wind blowing (the grass will move)
	-Make the pogo stick jump and move